// routes/api.js
const express = require('express');
const router = express.Router();
const Product = require('../models/product');

// Insert sample products
router.post('/seed', async (req, res) => {
  await Product.deleteMany({});
  await Product.insertMany([
    {
      name: "Casual T-Shirt",
      price: 499,
      category: "Clothing",
      variants: [
        { color: "Red", size: "M", stock: 25 },
        { color: "Blue", size: "L", stock: 16 }
      ]
    },
    {
      name: "Running Shoes",
      price: 2999,
      category: "Footwear",
      variants: [
        { color: "Black", size: "9", stock: 10 },
        { color: "White", size: "10", stock: 8 }
      ]
    }
  ]);
  res.send('Seeded!');
});

// Get all products
router.get('/products', async (req, res) => {
  const products = await Product.find({});
  res.json(products);
});

// Filter products by category
router.get('/products/category/:cat', async (req, res) => {
  const products = await Product.find({ category: req.params.cat });
  res.json(products);
});

// Project specific variant details (colors and stock only)
router.get('/products/variants', async (req, res) => {
  const products = await Product.find({}, { name: 1, "variants.color": 1, "variants.stock": 1 });
  res.json(products);
});

module.exports = router;
